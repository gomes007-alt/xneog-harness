import { type SnapshotStore } from '@xneog/dsh-client-store';
/**
 * Create the browser-wide trajectory duration preference source.
 * @returns a persisted source shared by every session view in one plugin lifecycle.
 */
export declare function createTrajectoryDurationStore(): SnapshotStore<boolean>;
//# sourceMappingURL=duration-store.d.ts.map