/**
 * Human-facing `/goal` command over the persisted same-session goal domain.
 * @module @xneog/dsh-command-goal
 */
import type { Context } from '@xneog/cordis';
export declare const name = "command-goal";
export declare const inject: string[];
/** Register the Codex-shaped `/goal` command for every composed command adapter. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map