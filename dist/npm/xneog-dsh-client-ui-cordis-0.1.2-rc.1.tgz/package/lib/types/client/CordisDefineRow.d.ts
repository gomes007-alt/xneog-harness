/** Read-only `cordis_define` card with Host and Client source tabs. */
import type { InjectFace, PropsLocale } from '@xneog/dsh-client-ui-slots';
import type { ToolCallViewProps } from '@xneog/dsh-client-ui-tool/client';
import type { CordisCardFace } from './slots.ts';
/** Full card props composed by the keyed Tool slot. */
export type CordisDefineRowProps = ToolCallViewProps & InjectFace<CordisCardFace> & PropsLocale<'cordis'>;
/** Render one immutable Package definition. */
export declare function CordisDefineRow({ callId, block, inspect, useInventory, useLoaded, t, }: CordisDefineRowProps): import("react").JSX.Element;
//# sourceMappingURL=CordisDefineRow.d.ts.map