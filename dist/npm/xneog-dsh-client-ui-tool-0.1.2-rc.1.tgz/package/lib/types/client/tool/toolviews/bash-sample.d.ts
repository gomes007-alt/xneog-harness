import type { Context } from '@xneog/cordis';
import type { PropsLocale } from '@xneog/dsh-client-ui-slots';
import type { ToolCallViewProps } from '../../contract/slots.ts';
type BashRowProps = ToolCallViewProps & PropsLocale<'conversation'>;
/** Renders expandable Bash output with an accessible lifecycle label. */
export declare function BashRow({ toolName, block, sessionId, useSessions, inspect, t }: BashRowProps): import("react").JSX.Element;
/** Registers the standalone Bash conversation-row sample. */
export declare const bashToolviewSample: {
    name: string;
    inject: string[];
    apply(ctx: Context): void;
};
export {};
//# sourceMappingURL=bash-sample.d.ts.map