import type { Context } from '@xneog/cordis';
import type { PropsLocale } from '@xneog/dsh-client-ui-slots';
import type { ToolCallViewProps } from '../../contract/slots.ts';
type FileMutationRowProps = ToolCallViewProps & PropsLocale<'conversation'>;
/**
 * Lets users expand an applied file diff and open the reported path.
 */
export declare function FileMutationRow({ toolName, block, cwd, home, openFile, inspect, t }: FileMutationRowProps): import("react").JSX.Element;
/** Registers the edit and write conversation rows. */
export declare const fileMutationToolview: {
    name: string;
    inject: string[];
    apply(ctx: Context): void;
};
export {};
//# sourceMappingURL=file-mutation-row.d.ts.map