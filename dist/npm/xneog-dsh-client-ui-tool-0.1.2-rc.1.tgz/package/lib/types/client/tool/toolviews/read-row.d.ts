import type { Context } from '@xneog/cordis';
import type { PropsLocale } from '@xneog/dsh-client-ui-slots';
import type { ToolCallViewProps } from '../../contract/slots.ts';
type ReadRowProps = ToolCallViewProps & PropsLocale<'conversation'>;
/**
 * Lets users expand a completed read result and open its reported path.
 */
export declare function ReadRow(props: ReadRowProps): import("react").ReactNode;
/** Registers the read tool's conversation row. */
export declare const readToolview: {
    name: string;
    inject: string[];
    apply(ctx: Context): void;
};
export {};
//# sourceMappingURL=read-row.d.ts.map