/** Platform-neutral assembly of generated Host Remote contributions. */
import type { Context } from '@xneog/cordis';
import type { ClientRemote } from '@xneog/dsh-api-gateway/client';
export type { ClientRemote } from '@xneog/dsh-api-gateway/client';
export type { PluginInventorySnapshot } from '@xneog/dsh-host-plugin-inventory/types';
export type {} from '@xneog/dsh-agent-presets/remote';
export type {} from '@xneog/dsh-commands/remote';
export type {} from '@xneog/dsh-api-settings-controller/remote';
export type {} from '@xneog/dsh-goal/remote';
export type {} from '@xneog/dsh-llm/remote';
export type {} from '@xneog/dsh-host-plugin-inventory/remote';
export type {} from '@xneog/dsh-message-feedback/remote';
export type {} from '@xneog/dsh-session-reference/remote';
export type {} from '@xneog/dsh-subagent/remote';
export type * from '@xneog/dsh-subagent/client';
export type {} from '@xneog/dsh-api-session-controller/remote';
export type * from '@xneog/dsh-api-session-controller/types';
export type {} from '@xneog/dsh-api-workspace-controller/remote';
export type * from '@xneog/dsh-api-workspace-controller/types';
export type { SessionJob as JobView } from '@xneog/dsh-api-session-controller/types';
export type { ApiRemoteForwardedEvent } from '../types.ts';
export type {} from '@xneog/dsh-commands/types';
export type {} from '@xneog/dsh-cordis-host-runner/types';
export type {} from '@xneog/dsh-credentials/types';
export type {} from '@xneog/dsh-llm/types';
export type {} from '@xneog/dsh-agent-presets/types';
export type {} from '@xneog/dsh-settings/types';
export type {} from '@xneog/dsh-user-approval/types';
export type {} from '@xneog/dsh-user-questions/types';
export type {} from '@xneog/dsh-api-session-controller/types';
/**
 * The carrier's Client-facing types, re-exported so a business package names one
 * assembly package instead of both this facade and the Connection plugin. Type-only:
 * the carrier's runtime values stay behind their own module edge.
 */
export type { ConnectionHandle, ConnectionSinks, ContentBlock, MessageId, RpcId, RpcRequest, RpcResponse, RpcResult, SessionId, StreamChunk, } from '@xneog/dsh-client-connection/client';
export type {} from '@xneog/dsh-api-gateway/client';
export type {} from '@xneog/dsh-cordis-host-runner/remote';
export type { ApprovalRequestId, CordisHalfState, CordisDynamicPackageId, CordisDynamicPluginId, CordisDynamicPluginRunId, CordisDynamicRunMode, CordisInspectMethodManifest, CordisInspectPlatform, CordisInspectProviderManifest, CordisInspectProviderView, CordisInspectQueryRequest, CordisInspectQueryResolution, CordisInspectQueryResolved, CordisInspectRequestId, CordisInspectResolveAck, CordisRunDiagnostic, CordisRunStatus, DynamicCordisClientSource, DynamicCordisHostHalfResult, DynamicCordisInventoryRow, DynamicCordisInvokeResult, DynamicCordisPackage, DynamicCordisRequestResolved, DynamicCordisResolveAck, DynamicCordisRetracted, DynamicCordisRunRequest, DynamicCordisRunResolution, DynamicCordisRunAttempt, DynamicCordisRunResponse, DynamicCordisStopResponse, DynamicCordisUndefineReceipt, RequestRunOutcome, } from '@xneog/dsh-cordis-host-runner/types';
export type { CredentialInfo } from '@xneog/dsh-credentials/types';
export type { SettingsDescribeValue, SettingsNamespaceView, SettingsPathOpView, SettingsSecretView, } from '@xneog/dsh-settings/types';
export type { LlmConfigurableProvider, LlmDiscoveredModel, LlmModelDiscoveryRequest, LlmProviderInfo, } from '@xneog/dsh-llm/types';
export type { FileReferenceCandidate } from '@xneog/dsh-file-reference/types';
export type { SessionReferenceMentionCandidate } from '@xneog/dsh-session-reference/types';
export type { RemoteErrorCode, RemoteErrorDetailsMap, RemoteFailure, RemoteResult, } from '@xneog/dsh-typert-protocol';
export type { RemoteHostFacts } from '@xneog/dsh-api-gateway/client';
declare module '@xneog/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by this Client assembly. */
        remote: ClientRemote;
    }
}
/** Required service: the typed Client Remote contribution mount. */
export declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map