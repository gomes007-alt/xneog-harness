/**
 * Browser-safe subagent projection and control vocabulary.
 *
 * @module @xneog/dsh-subagent/client
 */
export type * from './control-types.ts';
export type { SubagentIdentityProjection, SubagentTimingProjection } from './projection-types.ts';
//# sourceMappingURL=client.d.ts.map