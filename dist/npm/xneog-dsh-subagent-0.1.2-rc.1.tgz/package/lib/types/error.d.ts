/**
 * Typed failures shared by subagent service and provider operations.
 *
 * @module @xneog/dsh-subagent
 */
import { HarnessError } from '@xneog/dsh-llm';
/** Typed failure for the subagent seam. */
export declare class SubagentError extends HarnessError {
    constructor(message: string, code: string, options?: ErrorOptions);
}
//# sourceMappingURL=error.d.ts.map