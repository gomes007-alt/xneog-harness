import type { IconProps } from './icons/props.ts';
/**
 * xneog brand mark (placeholder): a bold rounded "x" rendered with
 * currentColor so it adapts to the active theme. Replace this placeholder
 * with the official xneog logomark when it is available.
 *
 * @param props.size - width/height in px (default 24).
 * @param props.className - extra class for layout placement.
 * @returns the logo svg (aria-hidden; pair with the wordmark for accessibility).
 */
export declare function BrandMark({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=BrandMark.d.ts.map