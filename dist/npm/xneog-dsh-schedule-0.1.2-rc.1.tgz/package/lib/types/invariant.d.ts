/**
 * Package-owned strict Schedule stream invariant.
 * @module @xneog/dsh-schedule/invariant
 */
import type { Context } from '@xneog/cordis';
/** Cordis invariant-companion plugin name. */
export declare const name = "tool-schedule-invariant";
/** Service required before reserving this package's invariant ownership. */
export declare const inject: string[];
/**
 * Register the package-owned invariant companion.
 * @param ctx - Cordis context carrying the invariant registry.
 * @returns Exact registration disposer after child setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map