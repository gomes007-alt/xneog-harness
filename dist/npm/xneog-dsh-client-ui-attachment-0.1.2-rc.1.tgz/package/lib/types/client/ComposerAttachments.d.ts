import type { ComposerAttachmentsProps } from '@xneog/dsh-client-ui-conversation/client';
/** Draft-image rail, document drop target, and original-image preview slot entry. */
export declare function ComposerAttachments({ attachments, canAcceptDrop, onAddImages, onRemoveImage, dropLimits, t, }: ComposerAttachmentsProps): import("react").JSX.Element;
//# sourceMappingURL=ComposerAttachments.d.ts.map