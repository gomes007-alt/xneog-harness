import type { TurnBoundaryProjection } from './types.ts';
declare module '@xneog/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** The agent session's open/last turn and step boundary facts (whole value). */
        turnBoundary: TurnBoundaryProjection;
    }
}
export {};
//# sourceMappingURL=projection.d.ts.map